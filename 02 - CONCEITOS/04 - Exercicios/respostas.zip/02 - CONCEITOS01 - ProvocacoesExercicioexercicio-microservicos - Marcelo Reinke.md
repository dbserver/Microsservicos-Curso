1. Qual � a principal vantagem de utilizar comunica��o ass�ncrona em uma arquitetura de microsservi�os?

a) Reduz a complexidade do sistema ao eliminar depend�ncias entre servi�os.<br/>
x  b) Diminui o acoplamento entre servi�os, aumenta a resili�ncia e reduz gargalos.<br/>
c) Garante que todos os microsservi�os compartilhem o mesmo banco de dados.<br/>
d) Elimina a necessidade de um message broker.<br/>

2. Sobre o uso de bancos de dados em microsservi�os, qual das alternativas est� correta?

x  a) Todos os microsservi�os devem compartilhar o mesmo banco de dados para manter consist�ncia.<br/>
b) Cada microsservi�o deve possuir seu pr�prio banco de dados para evitar acoplamento.<br/>
c) � obrigat�rio utilizar bancos distribu�dos para todos os microsservi�os.<br/>
d) A escolha do banco de dados � irrelevante para microsservi�os.<br/>

3. O que � essencial para lidar com concorr�ncia em um ambiente distribu�do?

x  a) Implementar bloqueios pessimistas ou otimistas e mutex para evitar condi��es de corrida.<br/>
b) Centralizar todas as opera��es em um �nico servi�o mestre.<br/>
c) Utilizar somente chamadas s�ncronas para coordenar os servi�os.<br/>
d) Garantir que todos os servi�os compartilhem um cache distribu�do.<br/>

4. Qual � o objetivo principal de observar logs, m�tricas e tracing distribu�do em microsservi�os?

a) Garantir que todos os servi�os utilizem os mesmos message brokers.<br/>
x  b) Facilitar a identifica��o de falhas e gargalos em um ambiente distribu�do.<br/>
c) Centralizar a configura��o dos microsservi�os em um �nico ponto de controle.<br/>
d) Substituir o uso de bancos de dados por arquivos de log.<br/>

5. Como o Domain-Driven Design (DDD) auxilia na arquitetura de microsservi�os?

a) Fornecendo uma �nica base de c�digo para todos os servi�os.<br/>
b) Garantindo que todos os servi�os compartilhem o mesmo contexto de dados.<br/>
x  c) Modelando cada servi�o dentro de seu pr�prio contexto delimitado (bounded context).<br/>
d) Substituindo a necessidade de comunica��o ass�ncrona entre servi�os.<br/>

As perguntas abaixo se referem a como se enxergam preparados para o uso destes conceitos e tecnologias.
Caso n�o seja desenvolvedor de backend ou da parte t�cnica mas fa�a parte da gest�o ou front end de alguma equipe, como enxergam sobre a equipe.
Caso n�o seja o caso responda "N�o se aplica".

As quest�es abaixo s�o descritivas:

6. Como voc� avalia o conhecimento individual e/ou do time que est�o inseridos para aplica��o pr�tica dos conceitos abordados como pr�-requisitos.
	Por mais que haja necessidade de conhecimento t�cnico novo, acredito que "pensar em microsservi�os" seja o maior desafio inicial.
	Imagino (sem saber se � poss�vel ou se � bom) em algo mais "pr�tico". Tipo pegar a estrutura atual de um sistema do Banrisul (CSS + Produto) e tentar definir (caso seja poss�vel) como seria a abordagem em microsservi�os. Posso estar viajando, sei l�.

7. Dos pontos apresentados, qual ou quais seriam as maiores dificuldades identificadas na sua equipe para migra��o do modelo atual para o modelo de microsservi�os.
	Algo bem espec�fico meu: trabalho, d� pra dizer, s� com .NET. E no Banrisul, execu��es ass�ncronas (que tanto se falou), no .NET, n�o s�o poss�veis. Precisa se usar JAVA (aqui tenho bem menos conhecimento).
	N�o tenho conhecimento total. Muitas coisas da "infra" (pra n�o dizer todas) a gente usa (configura uma vez/no in�co e deu - na verdade pede e � feito). Mas 100% sobre isso a gente n�o sabe como funciona/foi feito (eu pelo menos)

8. Dados os pontos apresentados, voc� identifica necessidade de treinamento ou de suporte em algum papel, conceito ou tecnologia? (Lembrando que o material atual n�o se predisp�e a ter a profundidade necess�ria para aplica��o)
	Ainda n�o sei se tenho capacidade de falar a respeito.
	Come�aria com uma quest�o: o Banrisul vai ter um framework espec�fico para microsservi�os?
	Acho que sobre isso deveriamos come�ar antes de tudo.
	