1. Qual é a principal vantagem de utilizar comunicação assíncrona em uma arquitetura de microsserviços?
b) Diminui o acoplamento entre serviços, aumenta a resiliência e reduz gargalos.<br/>

2. Sobre o uso de bancos de dados em microsserviços, qual das alternativas está correta?
b) Cada microsserviço deve possuir seu próprio banco de dados para evitar acoplamento.<br/>

3. O que é essencial para lidar com concorrência em um ambiente distribuído?
a) Implementar bloqueios pessimistas ou otimistas e mutex para evitar condições de corrida.<br/>

4. Qual é o objetivo principal de observar logs, métricas e tracing distribuído em microsserviços?
b) Facilitar a identificação de falhas e gargalos em um ambiente distribuído.<br/>

5. Como o Domain-Driven Design (DDD) auxilia na arquitetura de microsserviços?
c) Modelando cada serviço dentro de seu próprio contexto delimitado (bounded context).<br/>


As perguntas abaixo se referem a como se enxergam preparados para o uso destes conceitos e tecnologias.
Caso não seja desenvolvedor de backend ou da parte técnica mas faça parte da gestão ou front end de alguma equipe, como enxergam sobre a equipe.
Caso não seja o caso responda "Não se aplica".

As questões abaixo são descritivas:

6. Como você avalia o conhecimento individual e/ou do time que estão inseridos para aplicação prática dos conceitos abordados como pré-requisitos.
Alguns pontos como comunicação, métricas, concorrência, cache, são utilizados e conhecidos no meu time, comunicação assíncrona também utilizamos em alguns pontos, mas isso não é uma realidade de todos os times do Banrisul. Os maiores desafios estão relacionados a a acertar no nível de acoplamento entre os micro-serviços, ou seja, tornar os micro-serviços de fato independentes um do outro e não criar mini monoliotos. 

7. Dos pontos apresentados, qual ou quais seriam as maiores dificuldades identificadas na sua equipe para migração do modelo atual para o modelo de microsserviços.
O maior desafio é a base de dados separada para cada micro-serviço, o que pode causar a construção de mini monolitos. Isso falando só de conhecimento, mas existem outros inúmeros desavios relacionados a estrutura atual do Banrisul.

8. Dados os pontos apresentados, você identifica necessidade de treinamento ou de suporte em algum papel, conceito ou tecnologia? (Lembrando que o material atual não se predispõe a ter a profundidade necessária para aplicação)
Nas questões de arquiterura acho que seria necessário treinamento aprofundado e talvez suporte para discução de pontos específicos. Envolve algumas mudanças até em relação a forma como os times são estruturados. Além do conhecimento de novas ferramentas que são pouco ou nada utilizadas no Banrisul. Mas acredito que seja difícil sair da teoria sem algumas mudanças estruturais no Banrisul e certamente algumas coisas seriam adaptadas pois a mudança na estrutura poder ser grande demais para ser viável.